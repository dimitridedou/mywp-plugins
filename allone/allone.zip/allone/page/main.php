<?php
                                                                                                                    //
function get_directory_size($directory) {                                                                           //
    $size = 0;                                                                                                      //
    $dir = opendir($directory);                                                                                     // Άνοιγμα του φακέλου
    while (($file = readdir($dir)) !== false) {                                                                     // Η συνάρτηση θα περάσει από κάθε αρχείο και κάθε φάκελο που βρίσκεται μέσα σε έναν συγκεκριμένο φάκελο (directory).
        if ($file != '.' && $file != '..') {                                                                        //
            if (is_dir($directory . '/' . $file)) {                                                                 // Αν το στοιχείο είναι φάκελος, καλούμε την συνάρτηση αναδρομικά
                $size += get_directory_size($directory . '/' . $file);                                              //
            } else {$size += filesize($directory . '/' . $file);}                                                   // Αν το στοιχείο είναι αρχείο, προσθέτουμε το μέγεθός του στο συνολικό μέγεθος
        }                                                                                                           //
    }                                                                                                               //
    closedir($dir);                                                                                                 // Κλείνουμε τον φάκελο
    return $size;                                                                                                   //
}                                                                                                                   //
                                                                                                                    //
function my_dashboard_page() {                                                                                      // ΒΑΣΙΚΗ ΣΥΝΑΡΤΗΣΗ
    echo '<div class="wrap"><h1>Επισκόπηση</h1>';                                                                   //
    echo '<table class="wp-list-table widefat fixed striped">';                                                     // Δημιουργία του πίνακα
    echo '<tr><td><strong>Έκδοση WordPress</strong></td><td>'.esc_html(get_bloginfo('version')).'</td></tr>';       // Έκδοση WordPress
    echo '<tr><td><strong>Έκδοση PHP</strong></td><td>'.esc_html(phpversion()).'</td></tr>';                        // Έκδοση PHP
    echo '<tr><td><strong>Ενεργό Θέμα</strong></td><td>'.esc_html(wp_get_theme()->get('Name')).'</td></tr>';        // Ενεργό Θέμα
    $server_software = isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown';                //
    $server_name = isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'Unknown';                            //
    echo '<tr><td><strong>Τύπος Διακομιστή</strong></td><td>'.esc_html($server_software).'</td></tr>';              // Τύπος Διακομιστή
    echo '<tr><td><strong>Όνομα Διακομιστή</strong></td><td>'.esc_html($server_name).'</td></tr>';                  // Όνομα Διακομιστή
    echo '<tr><td><strong>URL Ιστότοπου</strong></td><td>' . esc_html(get_bloginfo('url')) . '</td></tr>';          //
    echo '<tr><td><strong>Μέγιστο Μέγεθος Upload</strong></td><td>'                                                 //
          .esc_html(size_format(wp_max_upload_size())).'</td></tr>';                                                //
    echo '<tr><td><strong>Μνήμη PHP</strong></td><td>' . esc_html(ini_get('memory_limit')) . '</td></tr>';          //
    echo '<tr><td><strong>SSL Ενεργοποιημένο</strong></td><td>' . (is_ssl() ? 'Ναι' : 'Όχι') . '</td></tr>';        //
    echo '<tr><td><strong>Λειτουργικό Σύστημα Διακομιστή</strong></td><td>' . esc_html(PHP_OS) . '</td></tr>';      //
    echo '<tr><td><strong>WordPress Size</strong></td><td>'                                                         //
    .esc_html(number_format(get_directory_size(ABSPATH)/1024/1024/1024,2)).'GB</td></tr>';                          //
    global $wpdb;                                                                                                   //
    $result = $wpdb->get_results("SELECT SUM(data_length + index_length)/1024/1024 AS size FROM information_schema.TABLES WHERE table_schema = '" . DB_NAME . "';", ARRAY_A );
    $db_size = $result[0]['size'];                                                                                  //
    echo '<tr><td><strong>Μέγεθος Βάσης Δεδομένων</strong></td><td>'.esc_html(round($db_size, 2)).' MB</td></tr>';  //
    echo '</tbody></table> </div>';                                                                                 //
                                                                                                                    //
                                                                                                                    //
    echo '<div class="wrap"><h1>Αναλυτικά Στοιχεία</h1>';                                                           //
    echo '<table class="wp-list-table widefat fixed striped">';                                                     // Δημιουργία του πίνακα
    echo '<thead><tr><th> </th><th>Συνολικός Αριθμός</th></tr></thead><tbody>';                                     // Συνολικός αριθμός
    echo '<tr><td><strong>Χρηστές</strong></td><td>'.esc_html(count_users()['total_users']).'</td></tr>';           // Xρηστών
    echo '<tr><td><strong>Tags</strong></td><td>'.esc_html(wp_count_terms('post_tag')).'</td></tr>';                // Tags
    echo '<tr><td><strong>Σελίδες</strong></td><td>'.esc_html(wp_count_posts('page')->publish).'</td></tr>';        // Σελίδες 
    echo '<tr><td><strong>Άρθρα</strong></td><td>'.esc_html(wp_count_posts('post')->publish).'</td></tr>';          // Άρθρα
                                                                                                                    //
    $query = new WP_Query(array(                                                                                    // Αρχείων
        'post_type'   => 'attachment',                                                                              //
        'post_status' => 'inherit',                                                                                 //
        'fields'      => 'ids',                                                                                     // Μόνο τα IDs για αποδοτικότητα    
        'posts_per_page' => -1                                                                                      // Λήψη όλων των attachments
    ));                                                                                                             //
    echo '<tr><td><strong>Αρχεία</strong> </td><td>'                                                                //
         .esc_html( count($query->posts)).'</td></tr>';                                                             //
                                                                                                                    // Αριθμός Πινάκων στην Βάση Δεδομένων
    global $wpdb;                                                                                                   //
    $tables = $wpdb->get_col("SHOW TABLES");                                                                        // Απόκτησε τον συνολικό αριθμό πινάκων στη βάση δεδομένων                                                 
    $total_tables = count($tables);                                                                                 // Υπολόγισε τον αριθμό των πινάκων  
    echo '<tr><td><strong>Πινάκες στην Βάση Δεδομένων</strong></td><td>'                                            // Εμφάνισε το αποτέλεσμα
          .esc_html($total_tables).'</td></tr>';                                                                    //
    echo '<tr><td><strong>Πινάκες στην Βάση Δεδομένων που είναι απο Plugin</strong></td><td>'                       // Εμφάνισε το αποτέλεσμα
    .esc_html($total_tables-11).'</td></tr>';                                                                       //
    echo '<tr><td><strong>Plugins</strong></td><td>'.esc_html(count(get_plugins())).'</td></tr>';                   // get_plugins() => // Λήψη όλων των plugins
    echo '<tr><td><strong>Active Plugins</strong></td><td>'                                                         // get_plugins() => // Λήψη όλων των plugins
            .esc_html(count(get_option('active_plugins'))).'</td></tr>';                                            //
    echo '<tr><td><strong>Inactive Plugins</strong></td><td>'                                                       // 
            .esc_html(count(get_plugins())-count(get_option('active_plugins'))).'</td></tr>';                       // count(get_plugins())-count(get_option('active_plugins'))
    echo '<tr><td><strong>Themes</strong></td><td>' . esc_html(count(wp_get_themes())) . '</td></tr>';              // Εμφάνιση του αριθμού των Themes
    echo '</tbody></table> </div>';                                                                                 //


    $users = get_users(array(                                                                   //
        'number' => 5,                                                                          // Αριθμός χρηστών
        'orderby' => 'post_count',                                                              // Ταξινόμηση με βάση τον αριθμό αναρτήσεων
        'order' => 'DESC'                                                                       // Φθίνουσα ταξινόμηση
    ));                                                                                         //
                                                                                                //
    echo'<h2 class="hndle"><span>Συνοπτικά Στατιστικά Χρηστών για Αναρτήσεις</span></h2>';      //
    echo'<div class="inside">';                                                                 //
    echo'<table class="wp-list-table widefat  fixed striped inside">';                          //
    echo'<thead><tr><th>Όνομα Χρήστη</th><th>Αριθμός Αναρτήσεων</th></tr></thead><tbody>';      //
      foreach ($users as $user) {                                                               //
        echo '<tr>';                                                                            //
        echo '<td>' . esc_html($user->display_name) . '</td>';                                  //
        echo '<td>' . esc_html(count_user_posts($user->ID)) . '</td>';                          //
        echo '</tr>';                                                                           //
     }                                                                                          //
    echo'</tbody></table></div>';                                                         //
    $recent_posts = wp_get_recent_posts(array(                                                  // Λήψη των 5 πιο πρόσφατων αναρτήσεων      
        'numberposts' => 5,                                                                     //
        'post_status' => 'publish'                                                              //
    ));                                                                                         //

}                                                                                                                   //
                                                                                                                    //






