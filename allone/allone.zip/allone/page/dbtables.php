<?php

function db_tables_stats_page() {
    global $wpdb;

    // Λήψη όλων των πινάκων
    $tables = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);

    echo '<div class="wrap">';
    echo '<h1>Στατιστικά Πινάκων Βάσης Δεδομένων</h1>';
    echo '<p><strong>Οι Βασικοι Πινακες (Χωρις προθεμα) : </strong> commentmeta / links / options / postmeta / posts / term_relationships / term_taxonomy
         / termmeta / terms / usermeta / users</p>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Όνομα Πίνακα</th><th>Συνολικός Αριθμός Εγγραφών</th><th>Συνολικό Μέγεθος (KB)</th><th>Ημερομηνία Δημιουργίας</th></tr></thead>';
    echo '<tbody>';

    foreach ($tables as $table) {
        // Υπολογισμός μεγέθους
        $data_size = $table['Data_length'] / 1024; // Μετατροπή σε KB
        $index_size = $table['Index_length'] / 1024; // Μετατροπή σε KB
        $total_size = $data_size + $index_size; // Συνολικό μέγεθος σε KB

        // Υπολογισμός συνολικού αριθμού εγγραφών
        $table_name = esc_sql($table['Name']);
        $row_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

        echo '<tr>';
        echo '<td>' . esc_html($table['Name']) . '</td>';
        echo '<td>' . number_format($row_count) . '</td>'; // Εμφάνιση του συνολικού αριθμού εγγραφών
        echo '<td>' . number_format($total_size, 2) . '</td>'; // Εμφάνιση του συνολικού μεγέθους
        echo '<td>' . esc_html($table['Create_time']) . '</td>'; // Εμφάνιση της ημερομηνίας δημιουργίας
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}