<?php
require_once plugin_dir_path( __FILE__ ) . '../postbox/editor-size.php';                               // Συνάρτηση που εμφανίζει το περιεχόμενο της σελίδας
function my_toggle_plugin_page() {                                                                  //
    if (isset($_POST['submit_toggle'])) {                                                           // Αποθήκευση της κατάστασης του διακόπτη
        $new_state = isset($_POST['my_toggle_state']) ? 'on' : 'off';                               //
        $new_state_short = isset($_POST['my_short_state']) ? 'on' : 'off';                          //
        update_option('my_toggle_state', $new_state);                                               //
        update_option('my_short_state', $new_state_short);                                          //
    }                                                                                               //
                                                                                                    //
     $short_state = get_option('my_short_state', 'off');                                            // Λήψη της τρέχουσας κατάστασης του διακόπτη
    $toggle_state = get_option('my_toggle_state', 'off');                                           // Λήψη της τρέχουσας κατάστασης του διακόπτη
    echo'<div class="wrap"> ';                                                                      //
    echo'<h1>Option</h1>';                                                                          //
    echo'<form method="post" action="">';                                                           //
                                                                                                    //
    echo'<label> Να φενεται το Μεγεθος της Σελιδας ή του Post στο Editor</label>';                  //
    echo'<label class="switch"> <input type="checkbox" name="my_toggle_state"';                     //
    checked($toggle_state, 'on');echo'> <span class="slider round"></span>';                        //                  
                                                                                                    //
    echo'</label><br><br><label>ShortCode Editor</label>';                                          //         
    echo'<label class="switch"><input type="checkbox" name="my_short_state"';                       //
    checked($short_state, 'on');echo'><span class="slider round"></span></label>';                  //                                                                          
                                                                                                    //
    echo'<p><input type="submit" name="submit_toggle" class="button button-primary" value="Αποθήκευση"></p>';                         
    echo'</form></div>';

    
    echo'
    <style>                                                                                         
        .switch {                                                                                   /* Στυλ για τον Διακόπτη */
            position: relative;                                                                     /**/
            display: inline-block;                                                                  /**/
            width: 34px;                                                                            /**/
            height: 20px; }                                                                         /**/
        .switch input {                                                                             /**/
            opacity: 0;                                                                             /**/
            width: 0;                                                                               /**/
            height: 0;}                                                                             /**/
        .slider {                                                                                   /**/
            position: absolute;                                                                     /**/
            cursor: pointer;                                                                        /**/
            top: 0;                                                                                 /**/
            left: 0;                                                                                /**/
            right: 0;                                                                               /**/
            bottom: 0;                                                                              /**/
            background-color: #ccc;                                                                 /**/
            transition: .4s;                                                                        /**/
            border-radius: 20px;    }                                                               /**/
        .slider:before {                                                                            /**/
            position: absolute;                                                                     /**/
            content: "";                                                                            /**/
            height: 12px;                                                                           /**/
            width: 12px;                                                                            /**/
            border-radius: 50%;                                                                     /**/
            left: 4px;                                                                              /**/
            bottom: 4px;                                                                            /**/
            background-color: white;                                                                /**/
            transition: .4s; }                                                                      /**/
        input:checked + .slider {background-color: #2196F3;}                                        /**/
        input:checked + .slider:before {transform: translateX(14px);}                               /**/
        .slider.round {border-radius: 20px;}                                                        /**/
        .slider.round:before {border-radius: 50%;}                                                  /**/
    </style>
   ';
   
}
