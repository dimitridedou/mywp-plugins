<?php
function display_files_from_root_directory() {                                                  //
                                                                                                // Ορίζουμε τον βασικό φάκελο από τον οποίο ξεκινάμε
    $base_directory = ABSPATH;                                                                  // Το ABSPATH δείχνει στον ριζικό φάκελο της εγκατάστασης WordPress
    $selected_folder = isset($_POST['folder']) ? sanitize_text_field($_POST['folder']) : '';    // Διαχείριση επιλογής φακέλου από την φόρμα
    $directory = rtrim($base_directory, '/') . '/' . ltrim($selected_folder, '/');              // Καθορίζουμε το path του επιλεγμένου φακέλου
                                                                                                //
    echo '<div class="wrap">';                                                                  // Αρχή HTML περιεχομένου
    echo '<h1>Αρχεία στον Φάκελο: '.esc_html($selected_folder).'</h1>';                         // 
                                                                                                //
    echo '<form method="POST" action="">';                                                      // Δημιουργία φόρμας για επιλογή φακέλου
    echo '<label for="folder">Επιλέξτε Φάκελο:</label>';                                        //
    echo '<select name="folder" id="folder" onchange="this.form.submit()">';                    //
    echo '<option value="">-</option>';                                                         //
    if ($selected_folder === ".") {                                                             // Αν ο επιλεγμένος φάκελος είναι ο root (δηλαδή η αρχική κατάσταση)
        echo '<option value="/wp-content/themes">Themes</option>';                              //
    }                                                                                           //
                                                                                                //
    if ($selected_folder === '') {                                                              // Αν ο επιλεγμένος φάκελος είναι ο ριζικός φάκελος
        $base_folders = array_filter(glob($base_directory . '*'), 'is_dir');                    // Εμφάνιση φακέλων από τον ριζικό directory
        foreach ($base_folders as $folder) {                                                    //
            $folder_name = basename($folder);                                                   //
            echo '<option value="'.esc_attr($folder_name).'"'.                                  //
                selected($selected_folder, $folder_name, false).'>'                             //
                .esc_html($folder_name).'</option>';                                            //
        }                                                                                       //
    } else {                                                                                    //
        $parent_folder = dirname($selected_folder);                                             // Εμφάνιση φακέλων από τον επιλεγμένο φάκελο
        if ($selected_folder !== ".") {                                                         // Ελέγχετε αν ο επιλεγμένος φάκελος είναι ο root φάκελος
            $parent_folder = dirname($selected_folder);                                         // Εύρεση του γονικού φακέλου
            $parent_folder_name = basename($parent_folder);                                     // Λήψη μόνο του ονόματος του γονικού φακέλου
            echo '<option value="'.esc_attr($parent_folder).                                    // Εμφάνιση του γονικού φακέλου με το όνομα του φακέλου
                 '">../'.esc_html($parent_folder_name).'</option>';                             //     
                                                                                                //
        }                                                                                       //
        $sub_folders = array_filter(glob($directory . '/*'), 'is_dir');                         // Λήψη και εμφάνιση υποφακέλων
        foreach ($sub_folders as $folder) {                                                     //
            $folder_name = basename($folder);                                                   //
            echo '<option value="'.esc_attr($selected_folder.                                   //
                 '/'.$folder_name).'"'.selected($selected_folder,$selected_folder.              //
                 '/'.$folder_name, false).'>'.esc_html($folder_name).'</option>';               //
        }                                                                                       //
    }                                                                                           //
    echo '</select>';                                                                           //
    echo '</form>';                                                                             //
                                                                                                //
    if (is_dir($directory)) {                                                                   // Εμφάνιση των Αρχείων και Φακέλων
        $items = scandir($directory);                                                           //
        $items = array_diff($items, array('.', '..'));                                          //
        echo '<ul class="file-list">';                                                          //
        foreach ($items as $item) {                                                             //
            $item_path = $directory . '/' . $item;                                              //
            if (is_file($item_path)) {                                                          //
                $file_url = esc_url(home_url('/').$selected_folder.'/'.$item);                  // Εμφάνιση Αρχείων
                  echo '<li class="file-item">'.esc_html($item).'</li>';                        //
            } elseif (is_dir($item_path)) {                                                     //
                 echo '<li class="folder-item">'.esc_html($item).'</li>';                       // Εμφάνιση Φακέλων
            }
        }
        echo '</ul>';
    } else {echo '<p>Ο φάκελος δεν υπάρχει ή δεν είναι προσβάσιμος.</p>';}
    echo '</div>';
}

function enqueue_custom_styles() {
    wp_enqueue_style('custom-style', plugin_dir_url(__FILE__) . '../css/files.css');
}
add_action('admin_enqueue_scripts', 'enqueue_custom_styles');

