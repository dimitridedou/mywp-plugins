<?php

function check_if_plugin_installed($plugin_slug) {                                                                  //
    $all_plugins = get_plugins();                                                                                   // Φορτώνουμε όλα τα plugins
    return array_key_exists($plugin_slug, $all_plugins); }                                                          // Ελέγχουμε αν το plugin υπάρχει στον πίνακα
                                                                                                                    //
function check_plugin_status($plugin_slug) {                                                                        //
    if (check_if_plugin_installed($plugin_slug)) {                                                                  // Ελέγχουμε αν το plugin είναι εγκατεστημένο
        if (is_plugin_active($plugin_slug)) {return 'Ενεργό';}                                                      // Ελέγχουμε αν το plugin είναι ενεργό
        else {return 'Απενεργοποιημένο';} }                                                                         // Ελέγχουμε αν το plugin είναι Απενεργοποιημένο
    else {return 'Δεν υπάρχει';}                                                                                    // Ελέγχουμε αν το plugin είναι Δεν υπάρχει
}                                                                                                                   //
                                                                                                                    //
function display_third_party_connections() {                                                                        //
    echo '<h2>Plugins</h2>';                                                                                        //
    echo '<table class="widefat fixed" cellspacing="0">';                                                           //
    echo '<thead><tr><th>Υπηρεσία</th><th>Κατάσταση</th></tr></thead><tbody>';                                      //
                                                                                                                    //
    $plugin_slug = 'woocommerce/woocommerce.php';                                                                   // Το slug του plugin Woocommerce
    $status = check_plugin_status($plugin_slug);                                                                    //
    if ($status == 'Δεν υπάρχει') {                                                                                 //
        echo '<tr><td>Woocommerce</td><td><a href="https://wordpress.org/plugins/woocommerce/">Εγκατάσταση</a></td></tr>';}
    else {echo '<tr><td>Woocommerce</td><td>'.$status.'</td></tr>';}                                                //
                                                                                                                    //
    $plugin_slug = 'contact-form-7/wp-contact-form-7.php';                                                          // Το slug του plugin Contact Form 7
    $status = check_plugin_status($plugin_slug);                                                                    //
    if ($status == 'Δεν υπάρχει') {                                                                                 //
        echo '<tr><td>Contact Form 7</td><td><a href="https://wordpress.org/plugins/contact-form-7/">Εγκατάσταση</a></td></tr>';}
    else {echo '<tr><td>Contact Form 7</td><td>'.$status.'</td></tr>';}                                             //
                                                                                                                    //
    $plugin_slug = 'classic-editor/classic-editor.php';                                                             // Το slug του plugin Google Analytics
    $status = check_plugin_status($plugin_slug);                                                                    //
    if ($status == 'Δεν υπάρχει') {                                                                                 //
        echo '<tr><td>Classic Editor</td><td><a href="https://wordpress.org/plugins/classic-editor/">Εγκατάσταση</a></td></tr>';}
    else {echo '<tr><td>Classic Editor</td><td>'.$status.'</td></tr>';}                                             //
                                                                                                                    //
    $plugin_slug = 'advanced-database-cleaner/advanced-db-cleaner.php';                                                             // Το slug του plugin Google Analytics
    $status = check_plugin_status($plugin_slug);                                                                    //
    if ($status == 'Δεν υπάρχει') {                                                                                 //
        echo '<tr><td>Advanced Database Cleaner</td><td><a href="https://wordpress.org/plugins/classic-editor/">Εγκατάσταση</a></td></tr>';}
    else {echo '<tr><td>Advanced Database Cleaner</td><td>'.$status.'</td></tr>';}                                             //

    echo '</tbody></table>';                                                                                        //
}