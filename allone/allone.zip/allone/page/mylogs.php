<?php
function my_debug_logs_page() {
    $log_file = plugin_dir_path(__FILE__) . '../files/debug.log';                                                    // Ορίστε το όνομα του αρχείου log
    if (isset($_POST['clear_log'])) {                                                                       //
        if (file_exists($log_file)) {                                                                       // Επεξεργασία του POST αιτήματος για διαγραφή του log
            file_put_contents($log_file, '');                                                               // Διαγραφή περιεχομένου του αρχείου
        }                                                                                                   //
        wp_redirect($_SERVER['REQUEST_URI']);                                                               // Ανακατεύθυνση για να αποφευχθεί επανυποβολή φόρμας
        exit;                                                                                               //
    }                                                                                                       //
                                                                                                            //
    if (file_exists($log_file)) {                                                                           //
        $logs = file_get_contents($log_file);                                                               //
    } else {                                                                                                //
        $logs = 'Το αρχείο log δεν υπάρχει.';                                                               //
    }                                                                                                       //
                                                                                                            //
    echo '<div class="wrap">';                                                                              //
    echo '<h1>Log Files</h1>';                                                                              //
    echo '<form method="post">';                                                                            //
    echo '<input type="submit" name="clear_log" value="Clear Log" class="button button-secondary">';        //
    echo '</form>';                                                                                         //
    echo '<pre>' . esc_html($logs) . '</pre>';                                                              //
    echo '</div>';                                                                                          //
}                                                                                                           //
                                                                                                            //
function prepend_to_log_file($log_entry){                                                                   //
    $log_file = plugin_dir_path(__FILE__).'../files/debug.log';                                                      //
    if (file_exists($log_file)) {                                                                           // Ανάγνωση του υπάρχοντος περιεχομένου του αρχείου
        $existing_content = file_get_contents($log_file);                                                   //
    } else {$existing_content = '';}                                                                        //
    $new_content = $log_entry . $existing_content;                                                          //
    file_put_contents($log_file, $new_content);                                                             // Εγγραφή της νέας περιεχομένου στο αρχείο
}                                                                                                           //
                                                                                                            //
function log_user_login($user_login, $user) {                                                               //
    $log_entry = sprintf(                                                                                   // Δημιουργία της καταγραφής
        "[%s] Χρήστης: %s (ID: %d) έχει συνδεθεί από IP: %s.\n",                                            //
        date('Y-m-d H:i:s'),                                                                                //
        $user_login,                                                                                        //
        $user->ID,                                                                                          //
        $_SERVER['REMOTE_ADDR']                                                                             //
    );                                                                                                      //
    prepend_to_log_file($log_entry);                                                                        // Προσθήκη στο αρχείο log
}                                                                                                           //
add_action('wp_login', 'log_user_login', 10, 2);                                                            //
                                                                                                            //
function log_login_failed($username) {                                                                      //
    $log_entry = sprintf(                                                                                   // Δημιουργία της καταγραφής
        "[%s] Αποτυχία σύνδεσης για το χρήστη: %s.\n",                                                      //
        date('Y-m-d H:i:s'),                                                                                //
        $username                                                                                           //
    );                                                                                                      //
    prepend_to_log_file($log_entry);                                                                        // Προσθήκη στο αρχείο log
}                                                                                                           //
add_action('wp_login_failed', 'log_login_failed');                                                          //
                                                                                                            //
function log_user_logout() {                                                                                //
    $log_entry = sprintf(                                                                                   // Δημιουργία της καταγραφής
        "[%s] Ο χρήστης έχει αποσυνδεθεί από IP: %s.\n",                                                    //
        date('Y-m-d H:i:s'),                                                                                //
        $_SERVER['REMOTE_ADDR']                                                                             //
    );                                                                                                      //
    prepend_to_log_file($log_entry);                                                                        // Προσθήκη στο αρχείο log
}                                                                                                           //
add_action('wp_logout', 'log_user_logout');                                                                 //

function log_user_register($user_id) {                                                                      //
    $user_info = get_userdata($user_id);                                                                    //
    $log_entry = sprintf(                                                                                   // Δημιουργία της καταγραφής
        "[%s] Δημιουργήθηκε νέος χρήστης: %s (ID: %d).\n",                                                  //
        date('Y-m-d H:i:s'),                                                                                //
        $user_info->user_login,                                                                             //
        $user_id                                                                                            //
    );                                                                                                      //
    prepend_to_log_file($log_entry);                                                                        // Προσθήκη στο αρχείο log
}                                                                                                           //
add_action('user_register', 'log_user_register');                                                           //

function log_user_update($user_id, $old_user_data) {                                                        //
    $user_info = get_userdata($user_id);                                                                    //
    $log_entry = sprintf(                                                                                   // Δημιουργία της καταγραφής
        "[%s] Ενημερώθηκε χρήστης: %s (ID: %d).\n",                                                         //
        date('Y-m-d H:i:s'),                                                                                //
        $user_info->user_login,                                                                             //
        $user_id                                                                                            //
    );                                                                                                      //
    prepend_to_log_file($log_entry);                                                                        //
}                                                                                                           //
add_action('profile_update', 'log_user_update', 10, 2);                                                     //
                                                                                                            //
function log_plugin_activation($plugin) {                                                                   //
    $log_entry = sprintf("[%s] Ενεργοποιήθηκε το πρόσθετο: %s.\n",date('Y-m-d H:i:s'),$plugin);             //
    prepend_to_log_file($log_entry);                                                                        //
}                                                                                                           //
add_action('activated_plugin', 'log_plugin_activation');                                                    //
                                                                                                            //
function log_plugin_deactivation($plugin) {                                                                 //
    $log_entry = sprintf("[%s] Απενεργοποιήθηκε το πρόσθετο: %s.\n",date('Y-m-d H:i:s'),$plugin);           //
    prepend_to_log_file($log_entry);  }                                                                     //                                                                                                           //
add_action('deactivated_plugin', 'log_plugin_deactivation');                                                //
                                                                                                            //
function log_theme_activation($new_theme) {                                                                 // Συνάρτηση για καταγραφή ενεργοποίησης θέματος
    $log_entry = sprintf("[%s] Ενεργοποιήθηκε το θέμα: %s.\n",date('Y-m-d H:i:s'),$new_theme);              // 
    prepend_to_log_file($log_entry);  }                                                                     // Κλήση της συνάρτησης για προσθήκη της καταγραφής στο αρχείο log
add_action('switch_theme', 'log_theme_activation');                                             
