<?php
function custom_file_editor_page() {
    ?>
    <div class="wrap">
        <h1>Custom Shortcode (Editor)</h1>
        <?php
        $filename = '/wp-content/plugins/allone/files/sort-code.php';                                                                 // Path to the file
        $filepath = ABSPATH . $filename;                                                                                        //
        if (isset($_POST['submit'])) {                                                                                          //
            $content = wp_unslash($_POST['content']);                                                                           //
            if (!file_exists($filepath)) {                                                                                      // Check if the file exists
                echo '<div class="error"><p>The specified file does not exist.</p></div>';                                      //
            } else {                                                                                                            //
                if (is_writable($filepath)) {                                                                                   // Check if the file is writable
                    if (file_put_contents($filepath, $content) === false) {                                                     // Attempt to write the content to the file
                      $error = error_get_last();                                                                                // Get the last error if writing failed
                      printf('<div class="error"><p>Failed to write to file. Error: %s</p></div>',esc_html($error['message'])); //
                    }                                                                                                           //
                    else {printf('<div class="updated"><p>File updated successfully.</p></div>');}                              //
                }                                                                                                               //
                else {echo '<div class="error"><p>The file is not writable. Please check the file permissions.</p></div>';}     //
            }                                                                                                                   //
        }                                                                                                                       //
        if (file_exists($filepath)) {$content = file_get_contents($filepath);}                                                  // Display file content editor form
        else {$content = '';}                                                                                                   //
        echo'<form method="post">';                                                                                             //
        echo'<input type="submit" name="submit" class="button button-primary" value="Update File"> <br> <br> ';                 // 
        echo'<textarea name="content" rows="100" cols="200">';                                                                  //
        echo esc_textarea($content);                                                                                            //
        echo'</textarea><br> </form></div>';                                                                                    //
       
}
