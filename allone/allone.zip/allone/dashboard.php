<?php

if ( ! defined( 'ABSPATH' ) ) {exit;}                                        // Ασφαλής εκτέλεση του αρχείου
require_once plugin_dir_path( __FILE__ ) . 'page/main.php';                  // Η σελίδα που περιέχει την Function για την Επισκόπηση
require_once plugin_dir_path( __FILE__ ) . 'page/mylogs.php';                // Η σελίδα που περιέχει την Function για τα  Logs
require_once plugin_dir_path( __FILE__ ) . 'page/plugins.php';               // Η σελίδα που περιέχει την Function για τα  Files
require_once plugin_dir_path( __FILE__ ) . 'page/dbtables.php';              // Η σελίδα που περιέχει την Function για τα  DB Tables
require_once plugin_dir_path( __FILE__ ) . 'page/editor.php';                // Η σελίδα που περιέχει την Function για το  Editor του Shortcode
require_once plugin_dir_path( __FILE__ ) . 'page/option.php';                // Η σελίδα που περιέχει την Function για τα  Plugins
require_once plugin_dir_path( __FILE__ ) . 'page/files.php';                 // Η σελίδα που περιέχει την Function για τα  Option
                                                                             //
function allone_menu() {                                                     // Προσθήκη κύριας σελίδας και υποσελίδων
    add_menu_page(                                                           // Κύρια σελίδα του dashboard
        'All One',                                                           // Τίτλος της σελίδας
        'Επισκόπηση',                                                        // Τίτλος του μενού
        'manage_options',                                                    // Δικαίωμα πρόσβασης
        'allone',                                                            // Slug για το μενού
        'my_dashboard_page',                                                 // Συνάρτηση για την κύρια σελίδα
        'dashicons-welcome-view-site',                                       // Εικονίδιο του μενού
        6     );                                                             // Θέση στο μενού
    add_submenu_page(                                                        //
        'allone',                                                            // Slug της κύριας σελίδας
        'Logs',                                                              // Τίτλος
        'Logs',                                                              // Τίτλος
        'manage_options',                                                    // Δικαίωμα πρόσβασης
        'allone-subpage3',                                                   // Slug για την υποσελίδα
        'my_debug_logs_page' );                                              // Συνάρτηση για την υποσελίδα                                                                         //
    add_submenu_page(                                                        //
        'allone',                                                            // Slug της κύριας σελίδας
        'Plugins',                                                           // Τίτλος της υποσελίδας
        'Plugins',                                                           // Τίτλος του μενού
        'manage_options',                                                    // Δικαίωμα πρόσβασης
        'allone-plugins',                                                    // Slug για την υποσελίδα
        'display_third_party_connections');                                  //
     add_submenu_page(                                                       //
        'allone',                                                            // Slug της κύριας σελίδας
        'DB Tables',                                                         // Τίτλος της υποσελίδας
        'DB Tables',                                                         // Τίτλος του μενού
        'manage_options',                                                    // Δικαίωμα πρόσβασης
        'allone-dbtables',                                                   // Slug για την υποσελίδα
        'db_tables_stats_page' );                                            // Συνάρτηση για την υποσελίδα  
    add_submenu_page(                                                        //
        'allone',                                                            // Slug της κύριας σελίδας
        'Files',                                                             // Τίτλος της υποσελίδας
        'Files',                                                             // Τίτλος του μενού
        'manage_options',                                                    // Δικαίωμα πρόσβασης
        'allone-Files',                                                      // Slug για την υποσελίδα
        'display_files_from_root_directory' );                               // Συνάρτηση για την υποσελίδα
    add_submenu_page(                                                        //
        'allone',                                                            // Slug της κύριας σελίδας
        'Option',                                                            // Τίτλος της υποσελίδας
        'Option',                                                            // Τίτλος του μενού
        'manage_options',                                                    // Δικαίωμα πρόσβασης
        'allone-Option',                                                     // Slug για την υποσελίδα
        'my_toggle_plugin_page'  );                                          // Συνάρτηση για την υποσελί    
    $toggle_state = get_option('my_short_state', 'off');                     //
    $post_types = array('post', 'page');                                     // Προσθέστε άλλους τύπους περιεχομένου αν χρειάζεται
    if ($toggle_state === 'on') {                                            //
        add_menu_page(                                                       // Κύρια σελίδα του dashboard
            'Shortcode',                                                     // Τίτλος της σελίδας
            'Shortcode',                                                     // Τίτλος της σελίδας
            'manage_options',                                                // Δικαίωμα πρόσβασης
            'my-Shortcode',                                                  // Slug για το μενού
            'custom_file_editor_page',                                       // Συνάρτηση για την κύρια σελίδα
            'dashicons-shortcode',                                           // Εικονίδιο του μενού
            7   );                                                           // Θέση στο μενού
    }                                                                        //
}                                                                            //
                                                                             //
add_action( 'admin_menu', 'allone_menu' );                                   // Προσθέτουμε το custum_menu στο Admin Menu 
