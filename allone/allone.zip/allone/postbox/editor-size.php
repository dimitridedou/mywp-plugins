<?php

function my_custom_meta_box() {                                                         // Συνάρτηση για την προσθήκη ή αφαίρεση του custom meta box
    $toggle_state = get_option('my_toggle_state', 'off');                               //
    $post_types = array('post', 'page');                                                // Προσθέστε άλλους τύπους περιεχομένου αν χρειάζεται
    if ($toggle_state === 'on') {                                                       //
        add_meta_box(                                                                   //
            'editor_sizes',                                                             // ID του meta box
            'Μέγεθος Σελίδας',                                                          // Τίτλος του meta box
            'my_custom_meta_box_content',                                               // Συνάρτηση που εμφανίζει το περιεχόμενο του meta box
            $post_type,                                                                 // Ο τύπος περιεχομένου (post, page, κλπ.)
            'side',                                                                     // Θέση (side, normal)
            'default'                                                                   // Προτεραιότητα
        );                                                                              //
    } else {                                                                            //
        remove_meta_box(                                                                //
            'editor_sizes',                                                             // ID του meta box
            'post',                                                                     // Ο τύπος περιεχομένου (post, page, κλπ.)
            'side'                                                                      // Θέση (side, normal)
        );                                                                              //
    }                                                                                   //
}                                                                                       //
add_action('add_meta_boxes', 'my_custom_meta_box');                                     //
                                                                                        //
function my_custom_meta_box_content() {                                                 // Περιεχόμενο του custom meta box
    global $post;                                                                       //
    $response = wp_remote_get(get_permalink($post->ID));                                // Ανάκτηση της σελίδας περιεχομένου μέσω wp_remote_get() ή άλλης μεθόδου
    if (is_wp_error($response)) {                                                       //
        echo '<p>Σφάλμα κατά την ανάκτηση δεδομένων.</p>';                              //
        return;                                                                         //
    }                                                                                   //
    $body = wp_remote_retrieve_body($response);                                         //
    $dom = new DOMDocument();                                                           // Εύρεση του πλήθους των εικόνων
    @$dom->loadHTML($body);                                                             //
    $images = $dom->getElementsByTagName('img');                                        //
    $image_count = $images->length;                                                     //
    $size = strlen($body);                                                              // Εύρεση μεγέθους της σελίδας
    echo '<p>Μέγεθος Σελίδας: ' . size_format($size) . '</p>';                          // Εμφάνιση των αποτελεσμάτων
    echo '<p>Αριθμός Εικόνων: ' . $image_count . '</p>';                                //
}
