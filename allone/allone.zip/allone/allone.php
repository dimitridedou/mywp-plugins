<?php
/*
Plugin Name: AllOne
Description: Ένα plugin που δείχνει συνολικά στοιχεία .
Version: 1.0
Author: <a href="#">Dimitris Dedousis</a>
*/


if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
require_once plugin_dir_path( __FILE__ ) . 'dashboard.php';


