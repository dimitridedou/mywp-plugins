<?php

function dgrcode_club_shortcode() {
    return 'Hello Word';                                    // Επιστρέφει το κείμενο που θέλεις να εμφανιστεί
}
add_shortcode('dgrcode_club', 'dgrcode_club_shortcode');    // Καταχώρηση του shortcode με το WordPress

?>
